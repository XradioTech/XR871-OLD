/*------------------------------------------------------------------------
* Xradio
* Reproduction and Communication of this document is strictly prohibited
* unless specifically authorized in writing by Xradio
*-------------------------------------------------------------------------
* Public header file between host application, oem_api.dll and firmware
*-----------------------------------------------------------------------*/

/*

OEM_API_VER - 0x0001
	a) Initial

*/

#ifndef _OEM_API_H_
#define _OEM_API_H_

#define OEM_API_VER                  0x0101

#pragma once

#define LINKAGE	__declspec(dllexport)

#ifdef __cplusplus
extern "C"
{
#endif

	//Function:	Get last status message	 
	//Param:	no
	//Return:	pointer of message string
	LINKAGE char* OEM_GetMsg();
	LINKAGE int OEM_SetHashKey(char* buf, int len);

	//Function:	Test encode data	 
	//Param:	encodeKey:	TRUE - encode key buf only
	//						FALSE - read encode result of last time
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_EncodeTest(char* buf, int len, BOOL encodeKey);

	//Function:	Init UART and key buffer
	//Param:	comNum: UART COM port
	//			keyBuf: buffer of encode key
	//			len: length of encode key
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_InitOem(int comNum, char* keyBuf, int len);
	LINKAGE int OEM_ExitOem();

	//Function:	Read/Write hosc
	//Param:	hosc: 0 - 26M   1 - 40M   2 - 24M   3 - 52M   -1 - invalid
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WriteHoscType(int hosc);
	LINKAGE int OEM_ReadHoscType(int* hosc);

	//Function:	Read/Write secure boot
	//Param:	hash: hash key buffer poiter
	//			Read len: equal or more than 32
	//			Write len: 32 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WriteScrBoot(char* hash, int len);
	LINKAGE int OEM_ReadScrBoot(char* hash, int len);

	//Function:	Read/Write DCXO trim
	//Param:	value: DCXO value
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WriteDcxoTrim(char value);
	LINKAGE int OEM_ReadDcxoTrim(char* value);

	//Function:	Read/Write POUT CAL
	//Param:	rfCal: POUT CAL buffer
	//			Read len: equal or more than 3
	//			Write len: 3 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WritePoutCal(char* rfCal, int len);
	LINKAGE int OEM_ReadPoutCal(char* rfCal, int len);

	//Function:	Read/Write MAC address
	//Param:	mac: MAC address buffer
	//			Read len: equal or more than 6
	//			Write len: 6 only
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WriteMacAddr(char* mac, int len);
	LINKAGE int OEM_ReadMacAddr(char* mac, int len);

	//Function:	Read/Write user area data
	//Param:	data: data buffer
	//			Read startAddr: 0 to 600
	//			Write startAddr: 0 to 600
	//			Read len: 1 to 601
	//			Write len: 1 to 601
	//Return:	0 - Success		1 - Failed
	LINKAGE int OEM_WriteUserArea(char* data, int startAddr, int len);
	LINKAGE int OEM_ReadUserArea(char* data, int startAddr, int len);

#ifdef __cplusplus
}
#endif

#endif // #ifndef _OEM_API_H_