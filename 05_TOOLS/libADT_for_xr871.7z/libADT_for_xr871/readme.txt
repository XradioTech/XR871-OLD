
1. put libADT.a into directory "lib/"
2. modify project/project.mk for link this libiary as follows:
    LIBRARIES += -lADT
3. make sure that the soundcard function is enabled in prj_config.h
    #define PRJCONF_SOUNDCARD0_EN           1
4. make sure the main stack size is enough for decoder, in prj_config.h
    #define PRJCONF_MAIN_THREAD_STACK_SIZE  (4 * 1024)
